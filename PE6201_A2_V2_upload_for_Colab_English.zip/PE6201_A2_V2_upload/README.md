# PE6201 A2 — Problem B submission runner

This repository contains the Problem B outpatient-referral implementation.
The canonical executable path is the root runner:

```text
run_eval.py -> agent.py -> tools.py
```

The `src/` directory supports the D4/D6 workbooks; it is not a second agent
entry point.

## Marker / D5(a) command

```bash
python3 run_eval.py
```

The committed default is `BACKEND = "scripted"`. It needs no API key, network,
or third-party package. It runs all 55 labelled Problem B cases, repeating
negative cases three times (93 trials), then writes `results.json`.

The deterministic paths derive from fixture-backed tools and never read the
answer key. They provide D5(a) reproducibility and D3/D4 integration evidence;
they are not live-model quality or D6 cost evidence.

## Layout

- `data_B/`, `expected_outcomes_B.json`: 55 cases and their ground truth.
- `tools.py`: fixture tools, v1/v2 descriptors, and code-level hostile-text
  detection.
- `agent.py`: instrumented ReAct loop and fail-closed policy stop.
- `guardrails.py`: step cap, token ceiling, nested-action de-duplication, and
  booking gate.
- `problem_b_scripts.py`: deterministic full-battery paths; no answer-key
  access.
- `harness.py`: D4 code check and judgement queue.
- `run_eval.py`: reproducible entry point.
- `scripts/check_my_data.py`: fixture and answer-key consistency check.
- `docs/`: concise handoffs for D2(b), D3, D4, and D5.

## Verify before upload

```bash
python3 scripts/check_my_data.py
python3 -m unittest discover -s tests -v
python3 run_eval.py
```

## D2(b): inspect both prompt versions

```bash
python3 run_eval.py --prompt --prompt-version v1
python3 run_eval.py --prompt --prompt-version v2
```

For a live D5(b) run, set the API key only in the environment. Never commit
keys, and never describe scripted token estimates as measured provider usage.

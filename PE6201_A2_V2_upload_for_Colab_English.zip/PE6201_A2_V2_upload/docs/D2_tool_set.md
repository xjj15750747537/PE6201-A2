# D2(a) tool-set rationale — Problem B

The root runner uses six small fixture-backed tools. A tool returns evidence;
the agent and the code-layer guards decide what that evidence means.

| Tool | Why it is needed | Deliberate boundary |
| --- | --- | --- |
| `get_referral` | Gives the case id its patient, specialty, free text, and attached tests. | Does not decide urgency, red flags, duplicate status, or booking. |
| `check_referral_criteria` | Combines the always-required protocol facts: hostile text, red flags, specialty fit, missing tests, and urgency band/window. | It reports facts only. It does not book or silently reroute. |
| `lookup_patient` | Supplies future appointments for the same-specialty duplicate check. | An empty list is normal; it is not a booking decision. |
| `as_of` | Makes urgency windows reproducible from a fixed date. | It is a clock, not a scheduling tool. |
| `get_clinic_slots` | Filters to legal specialty, band, date window, and positive capacity. | An empty list means escalate; it must not widen the window or change band. |
| `book_slot` | Makes the one permitted write-like action explicit and testable. | It is simulated, gated, and called only after all five routing checks pass. |

The combined criteria tool is intentional: all its checks are required for
every referral and each is a stop condition. Splitting it into separate tools
would add turns and make it easier for a live model to ask them in the wrong
order. The trade-off is documented through its detailed descriptor and the
D3 code guard, which independently blocks hostile free-text instructions.

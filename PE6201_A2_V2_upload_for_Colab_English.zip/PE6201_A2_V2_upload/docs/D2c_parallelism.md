# D2(c) dependency and parallelism policy — Problem B

The root runner accepts a batch of tool calls only when the calls are genuinely
independent. The current deterministic D5(a) paths are deliberately
conservative: they make the stop checks sequentially so a red flag, missing
test, hostile instruction, or duplicate cannot be followed by a needless slot
query.

| Dependency | Policy |
| --- | --- |
| `get_referral` | Always alone: every later call needs its output. |
| `check_referral_criteria` | After `get_referral`, before `lookup_patient` or slots in the conservative battery. |
| `lookup_patient` | Only after the criteria checks have passed. It must finish before a booking decision. |
| `as_of` and `get_clinic_slots` | The fixed clock can be read independently, but the slot query depends on the selected specialty and urgency band. |
| `book_slot` | Always alone, last, and behind the autonomy gate. |

A live-model experiment may batch independent read-only calls only if its trace
shows that no call depends on another call's result. It may never batch the
gated `book_slot` action with any other call. The scripted D5(a) battery is
not used to claim a parallelism saving; its purpose is reproducibility and
safe routing.

# D4 and D5 result contracts — canonical root runner

`python run_eval.py` is the reproducible D5(a) entry point. It runs all 55
labelled Problem B cases once, and repeats each negative case three times.
The current fixture set therefore produces 93 scripted trials. It writes the
machine-readable result to `results.json` in the repository root.

## `results.json`

The committed result is produced only by the scripted backend. Its fields
include:

```json
{
  "prompt_version": "v2",
  "summary": {"trials": 93, "passed": 93, "pass_rate": 1.0},
  "results": [
    {
      "case_id": "REF-5602",
      "trial": 1,
      "passed": true,
      "record": {
        "decision": "book",
        "booked": {"clinic": "OPH-C2", "date": "2026-10-14", "time": "11:20"},
        "turns": 5,
        "backend": "scripted"
      }
    }
  ],
  "judgement_queue": []
}
```

The scripted result demonstrates fixture consistency, routing integration,
action gating, and repeatability. Its token estimates and cost values are not
live-model measurements and must not be reused as D5(b) or D6 evidence.

## D4 judgement queue

The harness puts the non-automated evidence questions in `judgement_queue`.
For each selected case, a human reviewer or a named second-model reviewer must
record `verdict` and `graded_by`. The code check verifies fixed decision,
trigger, missing-item, and booking fields; it deliberately does not pretend to
grade free-text reasoning through a substring match.

## D5(b) live battery

Run live evaluation only with an API credential kept outside this repository.
For every actual model/case trial, save a separate results artifact with:

```json
{
  "model": "provider/model-name",
  "family": "provider-family",
  "price_tier": "cheap",
  "prompt_version": "v1",
  "case_id": "REF-5602",
  "input_tokens": 123,
  "output_tokens": 45,
  "turns": 4,
  "passed": true
}
```

`backends.LiveBackend` now fails loudly if the provider omits token-usage
metadata. Never replace missing live usage with scripted estimates or zeros.

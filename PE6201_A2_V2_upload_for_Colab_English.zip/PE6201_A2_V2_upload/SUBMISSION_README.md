# Submission checklist — PE6201 A2 Problem B

The marker entry point is:

```bash
python3 run_eval.py
```

The committed configuration is offline and deterministic:

```text
BACKEND = "scripted"
PROMPT_VERSION = "v2"
```

It runs the 55 labelled referrals with the one-normal/three-negative trial
rule, producing 93 trials and writing `results.json`. It needs no package
installation, API key, or network connection.

Before creating the final archive, run:

```bash
python3 scripts/check_my_data.py
python3 -m unittest discover -s tests -v
python3 run_eval.py
```

Expected checkpoint for this version:

```text
fixture check: PASS
unit tests: 16 passed
scripted D4/D5(a): 93 of 93 trials passed
```

`results.json` is a scripted reproducibility/integration result. Do not claim
that its estimated token counts or costs are live measurements. Live D5(b)
results must carry actual provider usage and may never contain an API key.
